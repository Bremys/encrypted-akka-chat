package messages;

public class SessionSuccsses extends Message {
}
