package messages;

public class SessionFail extends Message {
}
