package messages;

import java.io.Serializable;

public abstract class Message implements Serializable {

}
