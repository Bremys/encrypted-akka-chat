package messages;

public class IgnMsg extends Message {
}
