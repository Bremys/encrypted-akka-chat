package messages;

public class UserListMsg extends Message {
}
